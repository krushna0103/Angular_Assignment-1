import { Component } from "@angular/core";

@Component({
    selector : 'app-success',
    templateUrl: './success.component.html',
    styleUrl : '../app.component.css'
})

export class SuccessComponent{

}