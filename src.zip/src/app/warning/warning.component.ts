import { Component } from "@angular/core";

@Component({
    selector : 'app-warning',
    template  : `<p>Warning Alert!</p>`,
    styles: [
        `
            p {
                padding: 10px;
                background-color: moccasin;
                border: 1px solid red;
                font-weight : bold;
                color : red;
                text-align: center;
                }
        `
            ]
})

export class WarningComponent{

}